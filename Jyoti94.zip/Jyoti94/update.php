<?php
        $conn= new mysqli('localhost','root','','tybca');
        $id =$_GET['updateid'];
        echo $id;
        if(isset($_POST['submit'])){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $mobile=$_POST['mobile'];
            $password=$_POST['password'];
            $sql ="update leo set name='$name',email='$email',mobile='$mobile',password='$password'where id=$id";
        //excute query
        $result=mysqli_query($conn,$sql);
        //we will check
        if($result){
          echo "Data updated successfully";
          header("location:display.php");
          }else{
            die(mysqli_error($conn));
          }
        }
        $sql="Select * from leo where id=$id";
        $result=mysqli_query($conn, $sql);
        $row=mysqli_fetch_array($result);
        $name=$row['name'];
        $email=$row['email'];
        $mobile=$row['mobile'];
        $password=$row['password'];
        ?>
        <!doctype html>
        <html lang="en">
          <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

            <!-- Bootstrap CSS -->
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
          <title>Hello, world!</title>
          </head>
          <body>
          <form method="POST">
          <div class="mb-1">
            <label>name</label>
            <input type="name" class="form-control" name="name" value=<?php echo "$name";?> >
              </div>
              <div class="mb-2">
            <label>email</label>
            <input type="email" class="form-control" name="email"value=<?php echo "$email";?> >
              </div>
              <div class="mb-3">
            <label>mobile</label>
            <input type="Mobile" class="form-control" name="mobile"value=<?php echo "$mobile";?> >
              </div>
              <div class="mb-4">
            <label>password</label>
            <input type="Password" class="form-control" name="password"value=<?php echo "$password";?> >
              </div>
          
          <button type="submit" class="btn btn-primary" name="submit">submit</button>
        </form>
          </body>
        </html>