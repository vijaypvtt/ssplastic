  <?php
  $conn=new mysqli('localhost','root','','tybca');
 
  if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    //insert query
    $sql="Insert Into leo(name,email,mobile,password)
    Values('$name','$email','$mobile','$password')";
    //execute query
    $result=mysqli_query($conn,$sql);
    //we will check
    if($result){
      echo"data inserted successfully";
      // header("location:display.php");

    }else{
      die(mysqli_error($conn));

    }
  }
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
  <form method="POST">
  <class="mb-1">
    <label>name</label>
    <input type="Name" class="form-control" name="name"><br>
  </div>
  <div class="mb-2">
    <label >email </label>
    <input type="email" class="form-control" name="email"><br>
  </div>
  <div class="mb-3">
    <label >mobile</label>
    <input type="Mobile" class="form-control" name="mobile"><br>
  </div>
  <div class="mb-4">
  <label >password</label>
  <input type="Password" class="form-control" name="password"><br>
  </div>
    <button type="submit" class="btn btn-primary" name="submit">submit</button>
</form>
  </body>
</html>