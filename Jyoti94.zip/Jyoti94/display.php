<?php
$conn=new mysqli('localhost','root','','tybca');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  </head>
  <body>
    <div class="container"></div>


    <button type="button" class="btn btn-outline-success my-5"><a href="user.php">Add User</a></button>
    <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">sr.no</th>
      <th scope="col">name</th>
      <th scope="col">email</th>
      <th scope="col">mobile</th>
      <th scope="col">password</th>
      <th scope="col">operation</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql="select * from leo";
    $result=mysqli_query($conn,$sql);
   if($result){
   // $row=mysqli_fetch_array($result);
    //echo $row['name'];
    while($row=mysqli_fetch_array($result))
    {
      $id=$row['id'];
      $name=$row['name'];
      $email=$row['email'];
      $mobile=$row['mobile'];
      $password=$row['password'];
     echo '<tr>
  <tr>
      <th scope="row">'.$id.'</th>
      <td>'.$name.'</td>
      <td>'.$email.'</td>
      <td>'.$mobile.'</td>
      <td>'.$password.'</td>
      <td>
      <button type="button" name="updateid" class="btn btn-danger my-5"><a href="update.php?updateid='.$id.'">update</a></button>
      <button type="button" name="deleteid" class="btn btn-warning my-5"><a href="delete.php?deleteid='.$id.'">delete</a></button>
      </td>
    </tr>';
  }
   }
   ?>
  </tbody>
  </table>
  </body>
</html>