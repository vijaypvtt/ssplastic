<?php
$conn=new mysqli('localhost','root','','tybca');
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    //delete query
    $sql="delete from leo where id=$id";

    //execute query
    $result=mysqli_query($conn,$sql);

    //we will check
    if($result){
        echo"data inserted successfully";
        header("location:display.php");
    }else{
        die(mysqli_error($conn));
  
      }
}
?>